SELECT 
    trackID
FROM tracks
WHERE milliseconds < 1000000
;