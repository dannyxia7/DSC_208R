SELECT track.name
FROM track 
WHERE track.track_id NOT IN (SELECT invoice_line.track_id  From Invoice_line)
ORDER BY track.name ASC;
